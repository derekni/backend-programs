Name: Derek Ni
NetID: dan82
Issues: I ran into some issue with recursion when I was serializing the classes, assignments, and users.
Challenges: None.
Comments: Really interesting lab that taught me a lot about association tables and how to use SQLAlchemy!
